<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="text-center">
            <p>{{ date('Y') }} &copy; Phatrade</p>
        </div>
    </div>
</footer>
