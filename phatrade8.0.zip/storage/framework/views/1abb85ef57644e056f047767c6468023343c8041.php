<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/simple-datatables/style.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/vendors/perfect-scrollbar/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/vendors/sweetalert2/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/vendors/fontawesome/all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/css/app.css')); ?>">
    
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
    <div id="app">
        <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="main">
            <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="page-heading">
                <div class="page-title mb-3">
                    <div class="row">
                        <div class="col-12 col-md-6 order-md-1 order-last">
                            <h3><?php echo $__env->yieldContent('page-title'); ?></h3>
                        </div>
                        <div class="col-12 col-md-6 order-md-2 order-first">
                            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                                <ol class="breadcrumb">
                                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>

                <section class="section">
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
            </div>

            <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <script src="<?php echo e(asset('admin/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/jquery/jquery.min.js')); ?>"></script>
    <script>
        // Active Sidebar
        document.addEventListener('DOMContentLoaded', function() {
            const currentUrl = window.location.href;
            document.querySelectorAll('.sidebar-link').forEach(link => {
                if (link.href === currentUrl) {
                    link.classList.add('active');
                    let parent = link.closest('.sidebar-item');
                    if (parent) {
                        parent.classList.add('active');
                    }
                }
            });
        });

        // Sweet Alert 2
        let errors = <?php echo json_encode(json_encode($errors->all()), 15, 512) ?>;
        errors = JSON.parse(errors);
        if (errors.length > 0) {
            Swal.fire({
                icon: 'error',
                title: "Error",
                html: errors.join('<br>'),
                showConfirmButton: true,
            })
        }
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: "<?php echo e(session('success')); ?>",
                showConfirmButton: false,
                timer: 2000
            })
        <?php endif; ?>

        // <?php if(session('error')): ?>
        //     Swal.fire({
        //         icon: 'error',
        //         title: "Error",
        //         html: "<p class='text-center'> <?php echo e(__(session('error'))); ?> </p>",
        //         showConfirmButton: true
        //     })
        // <?php endif; ?>
    </script>

    <?php echo $__env->yieldContent('scripts'); ?>

    <script src="<?php echo e(asset('admin/vendors/simple-datatables/simple-datatables.js')); ?>"></script>
    <script>
        let table1 = document.querySelector('#table1');
        if (table1) {
            new simpleDatatables.DataTable(table1);
        }
    </script>

    <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\moame\Desktop\Freelancer\phatrade8.0\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>