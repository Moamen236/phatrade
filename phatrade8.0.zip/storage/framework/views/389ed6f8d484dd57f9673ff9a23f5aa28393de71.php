<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/pages/auth.css')); ?>">
</head>

<body>
    <div id="auth">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>

</html>
<?php /**PATH C:\Users\moame\Desktop\Freelancer\phatrade8.0\resources\views/admin/layouts/auth.blade.php ENDPATH**/ ?>