

<?php $__env->startSection('title', 'Certificates'); ?>

<?php $__env->startSection('content'); ?>
<section class="cert-banner">
    <h1>Our Certifications</h1>
    <p>PHATRADE maintains the highest standards of quality and compliance in the industry.</p>
</section>

<div class="certificates-container">
    <div class="certificates-grid">
        <?php $__currentLoopData = ['cert1', 'cert2', 'cert3', 'cert4', 'cert5', 'cert6']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="certificate-card">
                <a href="<?php echo e(asset('images/certificates/' . $certificate . '.pdf')); ?>" target="_blank">
                    <img src="<?php echo e(asset('images/certificates/thumbnails/' . $certificate . '.png')); ?>" alt="<?php echo e($certificate); ?> Thumbnail" class="certificate-thumbnail">
                </a>
                <a href="<?php echo e(asset('images/certificates/' . $certificate . '.pdf')); ?>" target="_blank" class="download-btn">
                    Download Certificate
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?> 

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
<link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moame\Desktop\Freelancer\phatrade8.0\resources\views/certificates.blade.php ENDPATH**/ ?>