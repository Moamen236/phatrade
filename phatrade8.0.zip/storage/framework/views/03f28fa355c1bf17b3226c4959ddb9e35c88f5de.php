<nav class="navbar">
    <div class="container">
        <div class="navbar-brand">
            <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Phatrade Logo" class="logo">
            </a>
            <button class="navbar-toggler" id="navbar-toggler">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
        
        <div class="navbar-menu" id="navbar-menu">
            <ul class="navbar-nav">
                <li><a href="<?php echo e(route('home')); ?>" class="nav-link">Home</a></li>
                <li><a href="<?php echo e(route('about')); ?>" class="nav-link">About Us</a></li>
                <li><a href="<?php echo e(route('products')); ?>" class="nav-link">Products</a></li>
                <li><a href="<?php echo e(route('farm')); ?>" class="nav-link">Farm</a></li>
                <li><a href="<?php echo e(route('factories')); ?>" class="nav-link">Factories</a></li>
                <li><a href="<?php echo e(route('certificates')); ?>" class="nav-link">Certificates</a></li>
                <li><a href="<?php echo e(route('contact')); ?>" class="nav-link">Contact Us</a></li>
            </ul>
        </div>
    </div>
</nav> <?php /**PATH C:\Users\moame\Desktop\Freelancer\phatrade8.0\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>