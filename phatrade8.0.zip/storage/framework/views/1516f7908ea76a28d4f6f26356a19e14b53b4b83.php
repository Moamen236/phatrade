

<?php $__env->startSection('title', 'Our Farm'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/farm.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="farm-intro" style="background-image: url(<?php echo e(asset($banner->image)); ?>)!important">
        <h1><?php echo e($banner->title); ?></h1>
        <p><?php echo e($banner->description); ?></p>
    </section>

    <!-- New Image Section -->
    <!-- Farm Images Section -->
        <section class="farm-images">
            <h2>Our Farm Images</h2>
            <div class="image-grid">
                <?php $__empty_1 = true; $__currentLoopData = $farms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="farm-card">
                        <img src="<?php echo e(asset($farm->image_path)); ?>" alt="<?php echo e($farm->name); ?>">
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No farms available at the moment.</p>
                <?php endif; ?>
            </div>
        </section>

    <div class="farm-container">
        <section class="farming-regions">
            <h2>Regional Production</h2>
            <div class="region-grid">
                <div class="region-card" data-aos="fade-up" data-aos-delay="100">
                    <h3>Delta Region</h3>
                    <ul>
                        <li>Jasmine</li>
                        <li>Violet</li>
                        <li>Carnation</li>
                    </ul>
                </div>

                <div class="region-card" data-aos="fade-up" data-aos-delay="200">
                    <h3>Beni Sweif</h3>
                    <ul>
                        <li>Basil</li>
                        <li>Chamomile</li>
                        <li>Onion</li>
                        <li>Geranium</li>
                        <li>Parsley</li>
                    </ul>
                </div>

                <div class="region-card" data-aos="fade-up" data-aos-delay="300">
                    <h3>Fayoum</h3>
                    <ul>
                        <li>Marjoram</li>
                        <li>Chamomile</li>
                        <li>Tagette</li>
                    </ul>
                </div>

                <div class="region-card" data-aos="fade-up" data-aos-delay="400">
                    <h3>Al-Minya</h3>
                    <ul>
                        <li>Marjoram</li>
                        <li>Coriander</li>
                    </ul>
                </div>

                <div class="region-card" data-aos="fade-up" data-aos-delay="500">
                    <h3>Asyout</h3>
                    <ul>
                        <li>Cumin</li>
                        <li>Fennel</li>
                    </ul>
                </div>

                <div class="region-card" data-aos="fade-up" data-aos-delay="600">
                    <h3>Aswan</h3>
                    <ul>
                        <li>Cassie</li>
                    </ul>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            AOS.init({
                duration: 800,
                easing: 'ease-in-out',
                once: true
            });
        });
    </script>
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moame\Desktop\Freelancer\phatrade8.0\resources\views/farm.blade.php ENDPATH**/ ?>