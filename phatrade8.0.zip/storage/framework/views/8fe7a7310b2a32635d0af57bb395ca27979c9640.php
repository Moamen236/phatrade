<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="text-center">
            <p><?php echo e(date('Y')); ?> &copy; Phatrade</p>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\moame\Desktop\Freelancer\phatrade8.0\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>