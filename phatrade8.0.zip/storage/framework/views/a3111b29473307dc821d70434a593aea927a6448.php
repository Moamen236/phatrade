

<?php $__env->startSection('content'); ?>
    <div class="banner" style="background-image: url(<?php echo e(asset($banner->image)); ?>)!important">
        <h1><?php echo e($banner->title); ?></h1>
    </div>

    <div class="products-section">
        <!-- Category Selection -->
        <div class="category-selection">
            <button class="category-btn active" data-category="all">All</button>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="category-btn" data-category="<?php echo e($category->slug); ?>"><?php echo e($category->name); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Product Grid -->
        <div class="product-grid" id="product-grid">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-card" data-category="<?php echo e($product->category->slug); ?>">
                    <div class="product-image">
                        <img src="<?php echo e(asset($product->image_path)); ?>" alt="<?php echo e($product->name); ?>">
                    </div>
                    <div class="product-content">
                        <h3><?php echo e($product->name); ?></h3>
                        <p><?php echo e($product->description); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <script>
        document.querySelectorAll('.category-btn').forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                document.querySelectorAll('.category-btn').forEach(btn => {
                    btn.classList.remove('active');
                });

                // Add active class to clicked button
                this.classList.add('active');

                const selectedCategory = this.getAttribute('data-category');
                const productCards = document.querySelectorAll('.product-card');

                productCards.forEach(card => {
                    if (selectedCategory === 'all' || card.getAttribute('data-category') ===
                        selectedCategory) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/products.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moame\Desktop\Freelancer\phatrade8.0\resources\views/products.blade.php ENDPATH**/ ?>