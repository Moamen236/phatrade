

<?php $__env->startSection('title', 'Our Factories'); ?>

<?php $__env->startSection('content'); ?>
    <section class="farm-intro" style="background-image: url(<?php echo e(asset($banner->image)); ?>)!important">
        <h1><?php echo e($banner->title); ?></h1>
        <p><?php echo e($banner->description); ?></p>
    </section>
    <div class="farm-container">
        <div class="factories-container">
            <?php $__currentLoopData = $factories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section class="factory-details">
                    <h2><?php echo e($factory->name); ?></h2>
                    <p><?php echo $factory->description; ?></p>
                    <div class="factory-images">
                        <?php if($factory->images): ?>
                            <?php $__currentLoopData = json_decode($factory->images, true) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(asset($image['path'])); ?>" alt="<?php echo e($factory->name); ?> Image" class="factory-image">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
        <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
        <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/farm.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/about.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moame\Desktop\Freelancer\phatrade8.0\resources\views/factories.blade.php ENDPATH**/ ?>